
	
	<!--Start setting!-->
		
		
<div align="center">
			<table border="0" width="177" cellpadding="0" cellspacing="0" height="31" >
				<thead>
					<td background="{$stylepath}/images/tradmin_03.gif" height="31" align="center">
					<div style="width:177px; height:31px; cursor:pointer" onclick="tradmin('setting','img-setting');return false"  >
					<table border="0" width="100%" cellspacing="0" cellpadding="0" height="100%">
						<tr>
							<td style="text-align: center; ">
							
							<b>�������� ������</b></td>
							<td width="18" style="text-align: center; ">
							
							<img border="0" src="{$stylepath}/images/collapse_off.gif" id="img-setting" width="9" height="9"></td>
						</tr>
					</table>
					</div>
					</td>
				</thead>
				
				<tr>
					<td align="center">
					<div id="setting">
						<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" style="border: 1px solid #62607C">
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
							<a href="setting.php?do=main">�������� ������ </a>
							</td>
							</tr>
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="setting.php?do=gd">������ ���� ������</a></td>
							</tr>
							
							</tr>
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="setting.php?do=style">������ ����� ���������</a></td>
							</tr>							
							</table>
					
					</td>
				</tr>
				
				</div>
			</table>
		</div>		
		<br>
		
		
		<!--End block setting!-->
	
	
		
	<!--Start Files!-->
		
		
<div align="center">
			<table border="0" width="177" cellpadding="0" cellspacing="0" height="31" >
				<thead>
					<td background="{$stylepath}/images/tradmin_03.gif" height="31" align="center">
					<div style="width:177px; height:31px; cursor:pointer" onclick="tradmin('files','img-files');return false"  >
					<table border="0" width="100%" cellspacing="0" cellpadding="0" height="100%">
						<tr>
							<td style="text-align: center; ">
							
							<b>������ ��������</b></td>
							<td width="18" style="text-align: center; ">
							
							<img border="0" src="{$stylepath}/images/collapse_off.gif" id="img-files" width="9" height="9"></td>
						</tr>
					</table>
					</div>
					</td>
				</thead>
				
				<tr>
					<td align="center">
					<div id="files">
						<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" style="border: 1px solid #62607C">
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
							<a href="files.php?do=extension">������ �����������</a>
							</td>
							</tr>
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="files.php?do=find">����� �� �������</a></td>
							</tr>
														
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="files.php?do=piclast">����� ��� ��� �����</a></td>
							</tr>
							
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="files.php?do=fileslast">������� ��� ��� �����</a></td>
							</tr>
							
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="files.php?do=allpic">��� ���� �����</a></td>
							</tr>
							
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="files.php?do=allfiles">��� ���� �������</a></td>
							</tr>	
							
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="files.php?do=report">��� ������� ������ ����</a></td>
							</tr>
							
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="files.php?do=delete">������ ��� �������</a></td>
							</tr>						
							
							</table>
					
					</td>
				</tr>
				
				</div>
			</table>
		</div>		
		<br>
		
		
		<!--End block Files!-->
		
		
		
	
	<!--Start sub pages!-->
		
		
<div align="center">
			<table border="0" width="177" cellpadding="0" cellspacing="0" height="31" >
				<thead>
					<td background="{$stylepath}/images/tradmin_03.gif" height="31" align="center">
					<div style="width:177px; height:31px; cursor:pointer" onclick="tradmin('pages','img-pages');return false"  >
					<table border="0" width="100%" cellspacing="0" cellpadding="0" height="100%">
						<tr>
							<td style="text-align: center; ">
							
							<b>����� ������</b></td>
							<td width="18" style="text-align: center; ">
							
							<img border="0" src="{$stylepath}/images/collapse_off.gif" id="img-pages" width="9" height="9"></td>
						</tr>
					</table>
					</div>
					</td>
				</thead>
				
				<tr>
					<td align="center">
					<div id="pages">
						<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" style="border: 1px solid #62607C">
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
							<a href="pages.php?do=rules">������ ������</a>
							</td>
							</tr>
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="pages.php?do=adv">���������</a></td>
							</tr>
							</table>
					
					</td>
				</tr>
				
				</div>
			</table>
		</div>		
		<br>
		
		
		<!--End block sub pages!-->
	
	
		<!--Start adminarea!-->
		
		
<div align="center">
			<table border="0" width="177" cellpadding="0" cellspacing="0" height="31" >
				<thead>
					<td background="{$stylepath}/images/tradmin_03.gif" height="31" align="center">
					<div style="width:177px; height:31px; cursor:pointer" onclick="tradmin('adminarea','img-adminarea');return false"  >
					<table border="0" width="100%" cellspacing="0" cellpadding="0" height="100%">
						<tr>
							<td style="text-align: center; ">
							
							<b>������� ������</b></td>
							<td width="18" style="text-align: center; ">
							
							<img border="0" src="{$stylepath}/images/collapse_off.gif" id="img-adminarea" width="9" height="9"></td>
						</tr>
					</table>
					</div>
					</td>
				</thead>
				
				<tr>
					<td align="center">
					<div id="adminarea">
						<table border="0" cellspacing="0" cellpadding="0" width="100%" height="100%" style="border: 1px solid #62607C">
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
							<a href="main.php?do=ip">����� ��� ��������</a>
							</td>
							</tr>
						
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="main.php?do=changepass">����� ���� ������</a></td>
							</tr>
							<tr>
								<td background="{$stylepath}/images/main_over.gif" onmouseover="this.background='{$stylepath}/images/main.gif'"  onmouseout="this.background='{$stylepath}/images/main_over.gif'">
								<a href="main.php?do=logout">����� ������</a></td>
							</tr>														
							</table>
					
					</td>
				</tr>
				
				</div>
			</table>
		</div>		
		<br>
		
		
		<!--End block adminarea!-->
			
	